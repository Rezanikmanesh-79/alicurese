from rest_framework.generics import GenericAPIView 
from rest_framework.response import Response
from rest_framework import status
from accounts.models import User
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.authtoken.models import Token
from .serializers import (RegistrationSerializers, CustomAuthTokenSerializer ,
                          CustomTokenObtainPairSerializer, ChangePasswordSerializer,
                          ProfileSerializer,DummySerializer
                          )
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from django.core.exceptions import ObjectDoesNotExist
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework.generics import RetrieveUpdateAPIView
from accounts.models import Profile
from django.shortcuts import get_object_or_404
from django.core.mail import send_mail

class RegistrationView(GenericAPIView):
    serializer_class = RegistrationSerializers

    def post(self, request, *args, **kwargs):
        serializer = RegistrationSerializers(data=request.data)
        if serializer.is_valid():
            serializer.save()
            data = {
                "email": serializer.validated_data['email']
            }
            return Response(data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class CustomAuthToken(ObtainAuthToken):
    serializer_class= CustomAuthTokenSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.serializer_class(data=request.data,
                                           context={'request': request})
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        token, created = Token.objects.get_or_create(user=user)
        return Response({
            'token': token.key,
            'user_id': user.pk,
            'email': user.email
        })
    

class CustoumDiscordeCustom(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        try:
            request.user.auth_token.delete()
        except ObjectDoesNotExist:
            pass  
        return Response(status=status.HTTP_204_NO_CONTENT)


class CustomTokenObtainPairView (TokenObtainPairView):
    serializer_class = CustomTokenObtainPairSerializer


class ChangePasswordView(GenericAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = ChangePasswordSerializer

    def put(self, request):
        serializer = self.get_serializer(data=request.data, context={"user": request.user})
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response({'success': 'Password changed successfully.'}, status=status.HTTP_200_OK)


class ProfileApiView (RetrieveUpdateAPIView):
    permission_classes = [IsAuthenticated]  
    serializer_class = ProfileSerializer
    queryset = Profile.objects.all()

    def get_object(self):
        queryset = self.get_queryset()
        obj = get_object_or_404(queryset, user=self.request.user)
        return obj


class TestEmailSend(GenericAPIView):
    serializer_class = DummySerializer
    def get(self, request, *args, **kwargs):
            send_mail(
                "Subject here",
                "Here is the message.",
                "from@example.com",
                ["to@example.com"],
                fail_silently=False,
                )
            return Response("email was send ")
