from accounts.api.v1 import views
from django.urls import path, include
#  from rest_framework.authtoken.views import ObtainAuthToken

urlpatterns = [
    # profile
    path('profile/', views.ProfileApiView.as_view(), name='profile')
]
