from django.test import TestCase
from django.urls import reverse, resolve
from blog.views import (PostlistView, PostDetailView)

class UrlsTest(TestCase):
    def test_blog_post(self):
        url = reverse('blog:post-list')
        resolver = resolve(url)
        self.assertEqual(resolver.func.view_class,PostlistView)

    def test_blog_post_detail(self):
        url = reverse('blog:post-detail', kwargs={'pk':1})
        resolver = resolve(url)
        self.assertEqual(resolver.func.view_class,PostDetailView)
