from django.test import TestCase
from django.urls import reverse
from blog.models import Post, Catgory
from accounts.models import User, Profile

class TestBlogView(TestCase):
    def setUp(self):
        self.user_obj = User.objects.create_user(email="test@test.com", password="12345#@987654")
        self.category_obj = Catgory.objects.create(name="hello")
        self.profile_obj = Profile.objects.create(
            user=self.user_obj,
            name='test_name',
            last_name='test_last_name',
        )
        self.post = Post.objects.create(
            title="Test Post",
            content="Test content",
            author=self.profile_obj,
            category=self.category_obj,
        )

    def test_blog_index_url_successful_response(self):
        url = reverse('blog:index')
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'index', response.content)
        self.assertTemplateUsed(response, 'index.html')

    def test_blog_detail_logged_in_response(self):
        self.client.force_login(self.user_obj)
        url = reverse("blog:post-detail", kwargs={'pk': self.post.id})
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_blog_detail_anonymous_in_response(self):
        url = reverse("blog:post-detail", kwargs={'pk': self.post.id})
        response = self.client.get(url)
        self.assertEqual(response.status_code, 302)
