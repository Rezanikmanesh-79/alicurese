from django.test import TestCase
from blog.models import Catgory
from blog.forms import ContactForm
from datetime import datetime


class FormTest(TestCase):
    def test_form_with_valid_data(self):
        catgory_obj = Catgory.objects.create(name="hello")
        form = ContactForm(data={
            "title": "test form",
            "content": "this is connect",
            "status": True,
            "catgory": catgory_obj.id,
            "published_date": datetime.now(),
        })
        self.assertTrue(form.is_valid())  

    def test_with_empty_form(self):
        form = ContactForm(data={})
        self.assertFalse(form.is_valid())
